import React from 'react'

const Withdraw=()=> {
  return (
    <div>withdraw</div>
  )
}

export default Withdraw