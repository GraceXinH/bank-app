import React from 'react'

const Deposit=()=> {
  return (
    <div>Deposit</div>
  )
}

export default Deposit