//the global variables are defined in App and also I provided UserContext in App 

import { createContext } from "react";
import React from "react";

export const UserContext = React.createContext(null);